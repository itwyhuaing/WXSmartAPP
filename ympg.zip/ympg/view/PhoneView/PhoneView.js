// phone-view.js
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

var that;
var countDownTimer;

function stopTimer() {
  if(countDownTimer){
    clearInterval(countDownTimer);
  }
}

function checkPhoneAndVCode(){
  //1.先判断是否绑定了手机号，绑定手机号不需要传手机号
  //2.再判断是否是微信手机号，是的话不需要传验证码
  if(util.isBindPhone()){
    return true
  }


  if (util.isEmpty(that.data.mobileCode)){
    that.setData({
      phoneInfo: '请输入手机号',
    })
     return false;
  }

  if (!util.chineseMobile(that.data.mobileCode)){
    that.setData({
      phoneInfo: '手机号有误，请重新输入',
    })
    report.click('100021')
    return false;
  }

  if(util.getWXPhoneNum() != getPhoneNum()){
    if (util.isEmpty(that.data.verticalCode)) {
      that.setData({
        vCodeInfo: '请输入验证码',
      })
      return false;
    }

    if (!util.checkVCode(that.data.verticalCode)) {
      that.setData({
        vCodeInfo: '验证码错误',
      })

      report.click('100023')
      return false;
    }
  }


  that.setData({
    phoneInfo: '',
    vCodeInfo: '',
  })

    return true;
}

function getPhoneNum(){
  return that.data.mobileCode;
}

function setPhoneNum(phone) {
  that.setData({
    mobileCode:phone
  })
}

function getVcode() {
  return that.data.verticalCode;
}

function setVcodeInfo(info){
  that.setData({
    vCodeInfo: info,
  });
}

function hideVcode(isHide){
  that.setData({
    showVCode: !isHide
  })
}


function init(){
  // this关键字必须传进来 这样才能使header.js中的数据和函数注入到这个模块
  that = this;

  //中相应的数据
  that.setData({
    showInputBtn:false,
    showVCode:false,
    showClearIc:false,
    showVcodeClearIc:false,
    mobileCode:'',//手机号
    verticalCode:'',//验证码
    vcodeBtnDisable:false,//
    phoneInfo:'',
    vCodeInfo: '',
    vcodeBtnTitle:'获取验证码'
  });

  wx.checkSession({
    success: function(){
      //session 未过期，并且在本生命周期一直有效

      that.setData({
        showInputBtn:true,
      });

    },
    fail: function(){
      //登录态过期
      that.setData({
        showInputBtn:false,
      });
    }
  })

  //获取手机好回调
  that.getPhoneNumber = function (e) {
    if(e.detail.errMsg.indexOf('ok') != -1){
      toast.showLoading('正在获取微信手机号')

      util.request({
        url: api.URL.getWXUserInfo,
        data:{
          appid:config.appid,
          encryptedData:e.detail.encryptedData,
          iv:e.detail.iv
        },
        success: function(res){
          if(res.data.state == 0){
            let phone = res.data.data
            util.setWXPhoneNum(phone)
            setPhoneNum(phone)
          }

          that.setData({
            showInputBtn:false,
          });
        },
        fail: function(res) {},
        complete: function(res) {
          toast.hideLoading()
        }
      })
      report.click('201001')
    }else{
      toast.showNotice('授权失败')

      that.setData({
        showInputBtn:false,
      });

      report.click('201002')
    }

  }

  //header中相应的 操作

  that.checkPhoneNum = function(phone){
    let showVCode = util.chineseMobile(phone)
    that.setData({
      showClearIc: phone.length > 0,
      showVCode: showVCode,
      phoneInfo: showVCode ? '' : that.data.phoneInfo,
      mobileCode: phone,
    });
  }

  //点击清除按钮
  that.clickClearIc = function(event){
    console.log('clickClearIc-')
    that.checkPhoneNum('');
  }

  //点击清除按钮
  that.clickVcodeClearIc = function (event) {
    that.setData({
      showVcodeClearIc: false,
      verticalCode: '',
    });
  }

  // 电话号码输入框
  that.mobileInputStatus = function (event) {
    that.checkPhoneNum(event.detail.value);
  }

  that.mobileInputBlur = function(event){
    that.setData({
      showClearIc: false,
      mobileCode: that.data.mobileCode,
    });
  }

  that.mobileInputFocus = function(event){
    that.setData({
      showClearIc: that.data.mobileCode.length > 0,
    });

    report.click('100019')
  }

  that.vcodeInputBlur = function (event) {
    that.setData({
      showVcodeClearIc: false,
      verticalCode: that.data.verticalCode,
    });
  }

  that.vcodeInputFocus = function (event) {
    that.setData({
      showVcodeClearIc: that.data.verticalCode.length > 0,
    });
    report.click('201010')
  }

  // 验证码输入框 
  that.vcodeInputStatus= function (event) {
    let verticalCode = event.detail.value;
    that.setData({
      showVcodeClearIc: verticalCode.length > 0,
      verticalCode: verticalCode,//验证码
      vCodeInfo: util.checkVCode(verticalCode) ? '' : that.data.vCodeInfo,
    });
  }

  //请求验证码
  that.reqVerticalCode = function (event){
    let mobileCode = that.data.mobileCode;

    // 发起网络请求
    util.request(
        {
          url: api.URL.vcode, // 119.29.58.95
          data: {
            mobile: mobileCode,
            type: 'mobile:collect',
          },
          success: function (res) {
            // success
            toast.showSuccess('验证码已发送');
          },
          fail: function () {
            // fail
            toast.showNotice('请求失败');
          },
          complete: function () {
            // complete
          }
        }
    )

    report.click('100022')

    // 倒计时
    let vcodeBtnDisable = true;
    that.setData({
      vcodeBtnDisable: true,
    });

    var tmpCount = 60
    countDownTimer = setInterval(function () {
      if (tmpCount <= 0) {
        clearInterval(countDownTimer);
        vcodeBtnDisable = false;
        that.data.vcodeBtnTitle = '重发验证码';
        that.setData({
          "vcodeBtnTitle": that.data.vcodeBtnTitle,
          "vcodeBtnDisable": vcodeBtnDisable,
        });
        return;
      }
      that.data.vcodeBtnTitle = tmpCount + 's后可重发';
      that.setData({
        "vcodeBtnTitle": that.data.vcodeBtnTitle,
      });
      tmpCount--;
    }, 1000);
  }
}

module.exports = {
  init: init,
  checkPhoneAndVCode: checkPhoneAndVCode,
  getPhoneNum: getPhoneNum,
  getVcode: getVcode,
  setVcodeInfo: setVcodeInfo,
  hideVcode: hideVcode,
  stopTimer:stopTimer
}