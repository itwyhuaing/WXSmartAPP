var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

Page({
  data: {  
    showPage: {
      state: 'loading'//loading、error、success
    }
  },

  tapItem : function(e) {
    var id = e.currentTarget.id;
    var title = e.currentTarget.dataset.title
    wx.navigateTo({
      url: '../BaikeList/BaikeList?country=' + id +'&title='+title
    });

    report.click("109001",{nation_id:id})
  },

  onLoad: function (options) {
    common.Page.init(options)

    var self = this
    var title = "国家百科"
    wx.setNavigationBarTitle({
      title: title
    })

    util.request({
      url: api.URL.wikiListWikiHome,
      data: {is_xcx:true},
      success: function (res) {
        console.log(res)
        // success
        if (res.data.state == 0) {
          self.setData({
            baikeArr: res.data.data,
            showPage: {
              state: 'success'//loading、error、success
            },
            // title: title,
            // type: type,
            // nation_id: contry,
          })
        } else {
          self.setData({
            showPage: {
              state: 'error'//loading、error、success
            },
          })
        }

      },
      fail: function () {
        // fail
        self.setData({
          showPage: {
            state: 'error'//loading、error、success
          },
        })
      }
    })
  },
  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {
    // Do something when page show.
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})