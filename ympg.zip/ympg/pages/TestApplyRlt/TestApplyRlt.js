var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')
var WxParse = require('../../view/wxParse/wxParse.js')

Page({

  data: {
    curProId: "",
    projectId:null,
    appImg:null,
    curProRltInfo:{},
    question_scoreProIDInfo:{},
    ref_desc_unsafe:""
  },

  goToiPhone:function(e){
    util.call400()
  },

  goToOnLine: function (e) {
    if(util.isBindPhone()){
      //需要请求接口

      wx.showModal({
        title: '预约成功',
        content: '资深顾问会在24小时内联系您，为您提供1对1的咨询服务。',
        showCancel:false,
        confirmText:'确定',
        confirmColor:'#3FA2FF',
        success: function(res) {
        }
      })
    }else{
      wx.redirectTo({
        url: '../Reservation/Reservation?projectId=' + this.data.projectId + "&img=https://cache.hinabian.com/" + this.data.appImg,
      });
    }
  },


  onLoad: function (options) {
    common.Page.init(options)
    var self = this;
    var app = getApp();
    self.data.curProId = options.nationProID;
    self.data.curProRltInfo = app.conditionTestRltInfo;
    self.data.projectId=app.conditionTestRltInfo.project_id
    self.data.appImg=app.conditionTestRltInfo.project.f_app_img
    self.data.question_scoreProIDInfo = app.conditionTestRltInfo.question_score[self.data.curProId];
    self.data.ref_desc_unsafe = app.conditionTestRltInfo.ref_desc[self.data.curProId];

    WxParse.wxParse('unsafeContext', 'html', self.data.ref_desc_unsafe, this, 15);

    self.setData({
      curProRltInfo: self.data.curProRltInfo,
      question_scoreProIDInfo: self.data.question_scoreProIDInfo,
      ref_desc_unsafe: self.data.ref_desc_unsafe
    });
  },
  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {
    // Do something when page show.
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})