var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var PhoneView = require('../../view/PhoneView/PhoneView.js')

var app = getApp();

var phoneNum = '';

var setIntervalCode;

Page({
  data:{
    imgSize: util.scaleImageAccordingScreen({
      width: 640,
      height: 379
    }),
    showMask : false,
    matchTitle:"",
    imassessedCount:app.globalData.imassessedCount,
    questionArr:null,
    answers: [],
    answersLast:5,//最后一题默认5
    answersCountry:[12021000,11011000,14011000],//加拿大、澳大利亚、香港
    isShow7Qa:false,//当用户选择加拿大、澳大利亚、香港，则显示问题——工作年限，问题数量为8，反之，则不显示问题——工作年限，问题数量为7
    params:['country','purpose','expense','overseas_residence_requirements','education','ielts','working_life'],
    countrys:['美国','爱尔兰','加拿大','澳大利亚','塞浦路斯','新西兰','希腊','马来西亚','格林纳达','香港地区'],
    isBindPhone: false,
    bid: '0000',
    cid: '0000',
  },

  handlerClickAnswer: function (e) {
    let questionIndex = e.currentTarget.dataset.questionIndex
    let optionIndex = e.currentTarget.dataset.optionIndex

    let questionArr = this.data.questionArr
    let answers = this.data.answers

    if (questionArr) {
      let question = questionArr[questionIndex]
      let option = question.option

      //先判断点击的item是否已经被选择
      let indexOfcheck = answers[questionIndex].indexOf(option[optionIndex].value)
      if (indexOfcheck != -1) {
        //被选择
        answers[questionIndex].splice(indexOfcheck, 1)
      } else {
        let max = question.max
        if (answers[questionIndex].length >= max) {
          answers[questionIndex].pop()
        }
        answers[questionIndex].push(option[optionIndex].value)
      }

      questionArr[questionIndex].option = this.setOptionChecked(option, answers[questionIndex])

      this.setData({
        questionArr: questionArr,
        answers: answers,
        isShow7Qa:this.checkShow7Qa(answers[0])
      })

      if (questionIndex == 0) {
        report.click('100011')
      } else if (questionIndex == 1) {
        report.click('100012')
      } else if (questionIndex == 2) {
        report.click('100013')
      } else if (questionIndex == 3) {
        report.click('100015')
      }else if (questionIndex == 4) {
        report.click('100016')
      }else if (questionIndex == 5) {
        report.click('100017')
      }else if (questionIndex == 6) {
        report.click('100018')
      }
    }
  },

  checkShow7Qa:function(answer0){
    if(!answer0 || answer0 == ''){
      return false
    }
    let answersCountry = this.data.answersCountry
    for(let i = 0 ;i < answersCountry.length ;i++){
      if(answer0.indexOf(answersCountry[i]) != -1){
        return true
      }
    }
    return false
  },

  setOptionChecked: function (option, answer) {
    if (option && answer) {
      option.map(function (item, index) {
        option[index].checked = (answer.indexOf(item.value) != -1)
      })

      return option
    }
  },

  checkedAnswer: function () {
    //判断是否选择全部题目
    let answers = this.data.answers
    for (let i = 0; i < answers.length; i++) {
      if(i == answers.length-1){
        if(this.data.isShow7Qa && answers[i].length == 0){
          return false
        }
      }else{
        if (answers[i].length == 0) {
          return false
        }
      }
    }
    return true
  },

  /**3. submitToReqWeb */
  submitToReqWeb:function(){

    if (!this.checkedAnswer()) {
      toast.showNotice('请选择全部问题');
      report.click('100020')
      return
    }

    //检查手机号：验证码
    let isPhoneRight = PhoneView.checkPhoneAndVCode();
    if (!isPhoneRight) {
      return;
    }

    var self = this;
    let answers = this.data.answers

    let postData = {}
    postData.appid = config.appid

    this.data.questionArr.map(function (item, index) {
      if(index == 6 && !self.data.isShow7Qa){
        postData[self.data.params[index]] = ''
      }else{
        postData[self.data.params[index]] = answers[index].join(',')
      }
    })

    postData['phone'] = PhoneView.getPhoneNum()
    postData['vcode'] = PhoneView.getVcode()
    postData['type'] = 'mobile:collect'
    postData['cid'] = report.getCRMCid(this.data.bid,this.data.cid)

    self.setData({
      showMask: true,
      matchTitle: "",
    });

    report.click('100024')

    util.request({
      url: api.URL.assessplan,
      data: postData,
      success: function (res) {
        // success
        let state = res.data.state
        if (res.data.state == 0) {
          try {
            app.globalData.pingGuResult = res.data.data
            wx.setStorageSync('KeyPingGuResult', res.data.data)
            util.setBindPhone(1)

            setIntervalCode=setInterval(function () {
              self.setData({
                matchTitle: "匹配中..." + self.data.countrys[util.randomInt(0,9)],
              });
            },500)

            setTimeout(function () {
              self.hiddenMask()
              wx.navigateTo({
                url: '/pages/IMAssessionResult/IMAssessionResult',
              });
            }, 3500);

          } catch (e) {
          }
        } else if (state == 12001000 || state == 12001003 || state == 110001 || state == 12001006) {
          PhoneView.setVcodeInfo(res.data.data);
          self.hiddenMask()

          report.click('100023')
        } else {
          toast.showNotice('请求失败', 1500);
          self.hiddenMask()
        }
      },
      fail: function () {
        toast.showNotice('请求失败', 1500);
        self.hiddenMask()
      },
    })
  },

  hiddenMask:function () {
    this.setData({
      showMask: false,
    });
    clearInterval(setIntervalCode)
  },

 loadData:function(){
   toast.showLoading();

   let self = this
   util.request({
     url: api.URL.assessQa,
     data: {},
     success: function (res) {
       // success
       toast.hideLoading();
       if(res.data.state == 0){
         let questionArr = api.parser.assessQa(res.data.data)
         let answers = api.parser.assessAnswers(questionArr)
         self.setData({
           questionArr:questionArr,
           answers:answers
         })
       }
     },
     fail: function () {
       // fail
       toast.showNotice('数据加载失败');
     }
   })
 },

  onLoad:function(options){
    common.Page.init(options)

    PhoneView.init.apply(this, []);

    if (options) {
      this.setData({
        bid:options.bid || "0000",
        cid:options.cid || "0000"
      })
    }


    //登录一下微信防止sessionKey过期，解密手机号失败
    util.wxLogin()

    this.setData({
      isBindPhone: util.isBindPhone(),
      imassessedCount:app.globalData.imassessedCount,
    })

    this.loadData();
  },
 
  onReady:function(){

  },
  onShow:function(){
    // 生命周期函数--监听页面显示
    if (!util.isEmpty(phoneNum) && phoneNum == PhoneView.getPhoneNum()) {
      PhoneView.hideVcode(true)
    }
  },
  
  onHide:function(){
    // 生命周期函数--监听页面隐藏
    this.setData({
      showMask: false,
    });

  },
  onUnload:function(){
    // 生命周期函数--监听页面卸载

  },
  onPullDownRefresh: function() {
    // 页面相关事件处理函数--监听用户下拉动作

  },
  onReachBottom: function() {
    // 页面上拉触底事件的处理函数

  },

  /**分享 */
  onShareAppMessage: function(){
    return{
      title:"免费智能移民评估 · 海那边",
      desc:"海那边在线移民评估系统，智能匹配移民项目，快速获得您的移民方案",
      path:"/pages/IMAssession/IMAssession"
    };
  },

})
