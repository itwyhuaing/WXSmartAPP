var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')

Page({

  data:{
    curProId:"",
    assessPro:"",
    curQuestions:[],
    multipleChoiceQuestions: [],
    rltChoices:{}
  },

  // 单选
  radioChange:function(e){
    /**
     var strs = e.detail.value.split("&");
    var tmpKey = "question[" + this.data.curProId + "][" + strs[0]+"]";
    var tmpValue = strs[1];
    if (tmpValue.length > 0){
      this.data.rltChoices[tmpKey] = tmpValue;
    }
    */
  },

  // 多选
  checkboxChange:function(e){
    var questionId = e.currentTarget.id
    var values = e.detail.value

    //先设置所有选择的状态
    for(var n = 0; n < this.data.curQuestions.length;n++){
      //问题
      if(questionId == this.data.curQuestions[n].id){
        //答案
        let answers = this.data.curQuestions[n].answer
        for(let j1=0 ; j1< answers.length ; j1++){
          let checked = false
          this.data.curQuestions[n].answer[j1].checked = false;
          for(let m = 0 ; m < values.length ; m++){
            if(values[m] == answers[j1].id){
              checked = true;
            }
          }
          this.data.curQuestions[n].answer[j1].checked = checked
        }
      }
    }


    //设置互斥
    if(values.length>1){
      var lastValue = values[values.length-1]
      for(let i = 0; i < this.data.curQuestions.length;i++){
        //问题
        let question = this.data.curQuestions[i]
        if(questionId == question.id){
          //答案
          let answers = question.answer
          for(let j=0 ; j< answers.length ; j++){
            if(lastValue == answers[j].id){
              let mutual_exclusion = answers[j].mutual_exclusion.trim()
              if(mutual_exclusion!=""){
                if(mutual_exclusion.indexOf(" ") == -1){
                  this.data.curQuestions[i].answer[parseInt(mutual_exclusion)-1].checked = false
                }else{
                  let indexsHuCi = mutual_exclusion.trim().split(" ")
                  for(let index in indexsHuCi){
                    this.data.curQuestions[i].answer[index].checked = false
                  }
                }
              }
            }
          }
        }
      }
    }

    this.setData({
      curQuestions:this.data.curQuestions
    })

  },

  formSubmit:function(e){
    
    var subStrCount = util.querySubstrFromString(e.detail.value);
    if(subStrCount == false){
      toast.showNotice('请选择全部问题');
      return ;
    }

    report.click("106002");
    var tmpRltInfo = e.detail.value;
    var self = this;
    var app = getApp();

    util.request({
      url: api.URL.saveTestForApp.format(self.data.curProId),
      data: tmpRltInfo,
      success: function (res) {
        // success
        if(res.data.state == 0){
          app.conditionTestRltInfo = res.data.data;
          wx.redirectTo({
            url: '/pages/TestApplyRlt/TestApplyRlt?nationProID=' + self.data.curProId
          })
        }
      },
      fail: function () {
        // fail
      },
    })

  },

  onLoad: function (options) {
    common.Page.init(options)
    var self = this;
    self.data.curProId = options.nationProID;
    self.data.assessPro = options.nationName ? "[" + options.nationName+"]" : "";

    util.request({
      url: api.URL.testForApp.format(self.data.curProId),
      data:{},
      success:function(res){
        if (res.data.state == 0){
          self.data.assessPro += res.data.data[0].name;
          let questions =  res.data.data[0].question;
          for(let i = 0 ; i < questions.length ; i++ ){
            let quest = questions[i]
            if(quest.type == 3){
              let context = quest.context
              context = context.substring(0,context.indexOf('（'))
              quest.placeholder = context
            }
          }
          self.data.curQuestions = questions;
          self.setData({
            assessPro: self.data.assessPro,
            curQuestions: self.data.curQuestions
          });
          console.log(" res :" + self.data.assessPro + "\n" + self.data.curQuestions.length);
        }
      },
      fail:function(){

      },
    })

  },
  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {
    // Do something when page show.
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})