var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')

Page({
  data: {
    url:'https://m.hinabian.com/native/project/countrys_wxxcx?cid='+config.projectName
  },

  onLoad: function(options) {
    common.Page.init(options)
  },
  onReady: function() {
    // Do something when page ready.
  },
  onShow: function() {
    // Do something when page show.
  },
  onHide: function() {
    // Do something when page hide.
  },
  onUnload: function() {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})