var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

var name='微信小程序用户'

Page({
  data: {
    projectId:null,
    img:null,
    bannerSize: util.scaleImageAccordingScreen({
      width: 710,
      height: 398
    }),
    isCanYuYue:false,
    isMobile:false,
    phoneNum:"",
    name:''
  },

  bindfocusName:function (e) {
    report.click('204003')
  },
  bindfocusPhone:function (e) {
    report.click('204004')
  },

  clickCommit:function (e) {
    toast.showLoading("正在提交预约...")

    wx.setStorageSync('phoneNum', this.data.phoneNum);
    util.request({
      url: api.URL.saveResForApp,
      data: {
        'mobile': this.data.phoneNum,
        'project_id': this.data.projectId,
        'name': this.data.name,
        'cid': config.cid.project + '-' + report.data.scene_channel,
      },
      success: function (res) {
        // success
        if (res.data.state == 0) {
          wx.redirectTo({
            url: '../ReservationSuccess/ReservationSuccess',
          });

          report.click('204006')
        }else{
          toast.showNotice("预约失败")

          report.click('204005')
        }
      },
      fail: function () {
        // fail
        toast.showNotice("预约失败")
        report.click('204005')
      },
    })
  },

  mobileInputStatus: function (event) {
    let isMobile= util.chineseMobile(event.detail.value)
    this.setData({
      isMobile:isMobile,
      phoneNum:event.detail.value,
      isCanYuYue:isMobile && this.data.name.length>0,
    })
  },

  usernameInputStatus: function (event) {
    let username= event.detail.value
    this.setData({
      name:username,
      isCanYuYue:this.data.isMobile && username.length>0,
    })
  },
  
  onLoad: function(options) {
    common.Page.init(options)

    this.setData({
      projectId:options.projectId,
      img:options.img,
      isMobile:wx.getStorageSync('phoneNum') ? true : false,
      phoneNum:wx.getStorageSync('phoneNum')
    })
  },
  onReady: function() {
    // Do something when page ready.
  },
  onShow: function() {
    // Do something when page show.
  },
  onHide: function() {
    // Do something when page hide.
  },
  onUnload: function() {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})