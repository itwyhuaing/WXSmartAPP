var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var app = getApp()


Page({
  data: {
    //菜单导航图标属性
    menuInfo:[
      { img: 'https://cache.hinabian.com/mobile/images/wxxcx/ic_menu_bake.png', title: '国家百科',  url:"../BaikeNationList/BaikeNationList" },
      { img: 'https://cache.hinabian.com/mobile/images/wxxcx/ic_menu_prj.png', title: '移民项目', url: "../ProjectList/ProjectList" },
      { img: 'https://cache.hinabian.com/mobile/images/wxxcx/ic_menu_ym.png', title: '移民交流群',  url: "../Invite/Invite" },
      { img: 'https://cache.hinabian.com/mobile/images/wxxcx/ic_menu_fc.png', title: '海外房产',  url: "" },
    ],

    //滑动banner图属性
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    circular: true,
    interval: 5000,
    duration: 1000,

    coverWindowShow:false,
    bannerSize: util.scaleImageAccordingScreen({
      width: 750,
      height: 406
    }),
    image1Size: util.scaleImageAccordingScreen({
      width: 619,
      height: 315
    }),
    rongyuInfoArr: [
      { img: 'https://cache.hinabian.com/images/team/220964724438374898_h5.png', title: 'ＣＥＯ谢仕梅', txt: '海那边创始人CEO: 谢仕梅拥有超过16年互联网从业经验，曾任腾讯高级产品经理、房多多运营总监。' },
      { img: 'https://cache.hinabian.com/mobile/images/team/guiHuaShi-h5.png', title: '部分规划师团队', txt: '海那边拥有顶级资质移民规划师，以专业的服务理念为您定制最合适的移民方案，帮你做最明智的移民决策。' },
      { img: 'https://cache.hinabian.com/mobile/images/team/wenAn-h5.png', title: '移民文案团队', txt: '海那边一线移民文案，平均从业经验超过10年，将成功为您移民作为己任，全程跟踪服务、及时高效处理您的移民申请。' },
      { img: 'https://cache.hinabian.com/mobile/images/team/jiShu-h5.png', title: '平台技术团队', txt: '海那边产品技术团队均来自知名互联网企业：腾讯、阿里、天涯等，历经逾10年的互联网从业经验。' },
      { img: 'https://cache.hinabian.com/mobile/images/team/lvShi-h5.png', title: '移民律师团队', txt: '海那边携手各国资深移民律师团队，为您解决移民相关的法律问题，确保最新移民政策资讯的及时传达及解析。' },
      { img: 'https://cache.hinabian.com/mobile/images/team/haiWaiFuWu-h5.png', title: '海外服务团队', txt: '海那边海外服务团队包括资深的税务、房产、教育、医疗等讯息提供专家、优秀贴心的接待陪同服务团队等，与您共同设计完美的海外生活。' },
    ],
    imassessedCount:254056,//评估人数
    bestPingguProject:null,

    meitiArr: [
      { img: 'http://cache.hinabian.com/mobile/images/wxxcx/img_meiti_china.jpg', url: "http://tech.china.com/article/20170713/2017071340313.html" },
      { img: 'http://cache.hinabian.com/mobile/images/wxxcx/img_meiti_163.jpg', url: "http://news.163.com/17/0525/10/CL99RURJ00014AEE.html" },
      { img: 'http://cache.hinabian.com/mobile/images/wxxcx/img_meit_tencent.jpg', url: "http://tech.qq.com/a/20160804/037910.htm" },
      { img: 'http://cache.hinabian.com/mobile/images/wxxcx/img_meiti_36kr.jpg', url: "http://36kr.com/p/5050110.html" },
    ],
    currentPage:0,
  },

  clickMenuItem: function(e){
    let index = e.currentTarget.dataset.index;
    let menuInfo = this.data.menuInfo

    if(0 == index){
      wx.navigateTo({
        url: menuInfo[index].url,
      });

      report.click('200023')
    }else if(1 == index){
      wx.switchTab({
        url: menuInfo[index].url,
      })

      report.click('200024')

    }else if(2 == index){
      wx.navigateTo({
        url: menuInfo[index].url,
      });

      report.click('200022')
    }else if(3 == index){
      wx.navigateToMiniProgram({
        appId: 'wxf57f12d2f8d514b2',
        envVersion: 'release',
      })

      report.click('200021')
    }
  },

  clickMeiti: function (e) {
    var url = e.currentTarget.dataset.url;
    wx.navigateTo({
      url: '../CommentWebView/CommentWebView?url=' + url
    });
  },
  
  changeScroll:function(e) {
    var cur = e.detail.current;
    this.setData({
      currentPage: cur
    });
  },
  clickScroll:function(e) {
    var cur = e.currentTarget.dataset.cur;
    var type = e.currentTarget.dataset.type;
    var len = this.data.meitiArr.length;
    if (type =='left'){
      if (cur == 0){
        return;
      }else{
        var current = parseInt(cur-1);
      }  
    }else{
      if (cur == (len - 1)){
        return;
      }else{
        var current = parseInt(cur+1) ;
      }
    }
    this.setData({
      currentPage: current
    })
  },

  loadBanner:function () {
    let self = this

    util.request({
      url: api.URL.homeBanner.format(config.projectName),
      success: function (res) {
        // success
        if (res.data.state == 0) {
          let banners = []
          res.data.data.map(function (item) {
            banners.push(item)
          })
          self.setData({
            imgUrls: banners
          });
        }
      }
    })
  },

  clickLookBest:function (e) {
    wx.navigateTo({
      url: '/pages/ProjectDetail/ProjectDetail?projectId='+this.data.bestPingguProject.pid,
    });

    report.click('200034')
  },

  clickRestartPingGu:function (e) {
    wx.navigateTo({
      url: '/pages/IMAssession/IMAssession',
    });

    report.click('200032')
  },

  clickGotoPinggu:function (e) {
    wx.navigateTo({
      url: '/pages/IMAssession/IMAssession',
    });

    report.click('200031')
  },

  clickGotoPingguWindow:function (e) {
    wx.navigateTo({
      url: '/pages/IMAssession/IMAssession',
    });

    this.setData({
      coverWindowShow:false
    })

    report.click('200004')
  },

  clickMoreProject:function (e) {
    wx.navigateTo({
      url: '/pages/IMAssessionResult/IMAssessionResult',
    });
    report.click('200033')
  },

  clickCoverClose:function (e) {
    this.setData({
      coverWindowShow:false,
    })
    report.click('200005')
  },

  clickCallPhone:function (e) {
    util.call400()

    report.click('200051')
  },

  onLoad: function (options) {
    common.Page.init(options)


    this.loadBanner()

    var self = this
    toast.showLoading("正在加载数据...")

    // 1. 请求有多少人已评估过
    util.request({
      url: api.URL.assessNum,
      success: function (res) {
        // success
        if (res.data.state == 0) {
          app.globalData.imassessedCount = res.data.data
          self.setData({
            imassessedCount: res.data.data
          });
        }
      },
      complete:function () {
        toast.hideLoading()
      }
    })

    this.checkLogin()
  },

  showCoverWindow:function () {
    let coverWindowShow = this.data.coverWindowShow
    if(!this.data.bestPingguProject){
      coverWindowShow = true
      report.click('200003')
    }

    this.setData({
      coverWindowShow:coverWindowShow
    })
  },

  checkLogin:function () {
    var that = this
    wx.checkSession({
      success: function(){
        //session 未过期，并且在本生命周期一直有效
        that.showCoverWindow()
      },
      fail: function(){
        //登录态过期
        util.wxLogin({
          success:function () {
            that.showCoverWindow()
          },
          fail:function () {
            that.showCoverWindow()
          }
        })
      }
    })
  },
  onReady: function () {
  },

  checkedBestPingGu:function(){
    if(app.globalData.pingGuResult){
      let pingGuResult = app.globalData.pingGuResult[0]
      this.setData({
        bestPingguProject:pingGuResult
      })
    }

  },

  onShow: function () {
    this.checkedBestPingGu()

    wx.setNavigationBarTitle({
      title: ''
    })
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})