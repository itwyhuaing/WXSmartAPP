var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

Page({
  data: {
    text: "This is page data."
  },

  clickConfirm:function (e) {
    wx.switchTab({
      url: '../Home/Home',
    });

    report.click('204007')
  },


  onLoad: function(options) {
    common.Page.init(options)
  },
  onReady: function() {
    // Do something when page ready.
  },
  onShow: function() {
    // Do something when page show.
  },
  onHide: function() {
    // Do something when page hide.
  },
  onUnload: function() {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})