var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')


var WxParse = require('../../view/wxParse/wxParse.js');

var app = getApp();

Page({
  data: {
    wordId:null,
    data:null,
    is_praise:null,
    showPage:{
      state:'loading'//loading、error、success
    },
  },

  clickUse:function (e) {
    if(this.data.is_praise !='0'){
      return;
    }
    this.setData({
      is_praise:'1',
    })
    this.clickUseState('praise')
  },
  clickUnUse:function (e) {
    if(this.data.is_praise !='0'){
      return;
    }
    this.setData({
      is_praise:'2',
    })
    this.clickUseState('negative')
  },

  clickUseState:function (state) {
    util.request({
      url: api.URL.useState.format(this.data.wordId,state),
    })
  },

  onLoad: function(options) {
    common.Page.init(options)

    var self = this
    var wordId = options.wordId
    var title = options.title

    wx.setNavigationBarTitle({
      title: title
    })

    util.request({
      url: api.URL.wikiDetail.format(wordId),
      success: function (res) {
        // success
        if (res.data.state == 0) {
          var f_content = res.data.data.f_content

          self.setData({
            data:res.data.data,
            is_praise:res.data.data.is_praise,
            showPage:{
              state:'success'//loading、error、success
            },
            title: title,
            wordId:wordId,
            screenSize:util.getScreen(),
          })

          WxParse.wxParse('contentText', 'html', f_content, self,25);

        }else{
          self.setData({
            showPage:{
              state:'error'//loading、error、success
            },
          })
        }
      },
      fail: function () {
        // fail
        self.setData({
          showPage:{
            state:'error'//loading、error、success
          },
        })
      }
    })

  },
  onReady: function() {
    // Do something when page ready.
  },
  onShow: function() {
    // Do something when page show.
  },
  onHide: function() {
    // Do something when page hide.
  },
  onUnload: function() {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})