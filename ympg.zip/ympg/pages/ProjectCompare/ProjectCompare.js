var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    pid:null,
    titleArr:['项目名称','语言环境','资金要求','适用目的','居住要求','办理周期','学历要求','工作年限'],
    keyIndexArr:['pname', 'f_lang_env', 'fund_need', 'purpose', 'residency_req_detail', 'cycle', 'education', 'working_life'],
    matchData:null
  },

  parseMatchData:function (apiData) {
    if(!apiData && !apiData.match){
      return []
    }

    let keyIndexArr = this.data.keyIndexArr

    let matchData = []
    apiData.match.map(function (item,index) {
      let matchItem = []
      keyIndexArr.map(function (item2,index2) {
        if(index2 == 0){
          matchItem.push(item[item2])
        }else if(index2 == 3){
          //使用目的
          let purpose = []
          let name = item[item2].name
          if(name && name.length>0){
            name.map(function (item,index) {
              if(item.ismatch){
                purpose.push(item.name)
              }
            })
          }
          matchItem.push(purpose)
        }else if(index2 == 2){
          matchItem.push(item[item2].value.min + '万起')
        }else{
          matchItem.push(item[item2].name)
        }

      })

      matchData.push(matchItem)
    })

    return matchData
  },

  clickZhuangjia:function (e) {
    util.call400()
    report.click('108001')
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    common.Page.init(options)
    let self = this
    let pid = options.pid

    wx.setNavigationBarTitle({
      title: '项目对比（{0}）'.format(pid.match(/,/g).length+1)
    })

    this.setData({
      pid:pid
    })

    wx.showNavigationBarLoading()

    util.request({
      url: api.URL.projectcompare.format(pid),
      success: function (res) {
        // success
        let state = res.data.state
        if (state == 0) {
          let matchData = self.parseMatchData(res.data.data)
          self.setData({
            matchData:matchData
          })
        }
      },
      fail: function () {
        toast.showNotice('请求失败', 1500);
      },
      complete:function () {
        wx.hideNavigationBarLoading()
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

})