var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')


var PhoneView = require('../../view/PhoneView/PhoneView.js')

var app = getApp();

Page({

  /**
   * 页面的初始数据
   */
  data: {
    bannerSize: util.scaleImageAccordingScreen({
      width: 750,
      height: 325
    }),
    pingGuResult: null,
    matchImages:['https://cache.hinabian.com/mobile/images/assess/icon-assess-right.png',
      'https://cache.hinabian.com/mobile/images/assess/icon-assess-warn.png',
      'https://cache.hinabian.com/mobile/images/assess/icon-assess-err.png'],
    compareProject:[]//比较的项目
  },

  clickAssessResultItem:function (e) {
    wx.navigateTo({
      url: '/pages/ProjectDetail/ProjectDetail?projectId='+e.currentTarget.dataset.projectId,
    });

    report.click("107001")
  },

  setCompareState:function (pingGuResult,compareProject) {
    if(pingGuResult && compareProject){
      pingGuResult.map(function (item,index) {
        pingGuResult[index].showCancel = compareProject.indexOf(item.pid) != -1
      })
    }

    return pingGuResult
  },

  clickCompare:function (e) {
    let cancel = e.currentTarget.dataset.cancel
    let pid = e.currentTarget.dataset.pid
    let compareProject = this.data.compareProject

    let indexOf = compareProject.indexOf(pid)

    report.click("107002",{f_project:pid,f_type:cancel?0:1})

    if(cancel){
      if(indexOf!=-1){
        compareProject.splice(indexOf, 1)
      }
    }else{
      if(compareProject.length>=4){
        toast.showNotice('最多对比四个项目')
        return
      }
      if(indexOf == -1){
        compareProject.push(pid)
      }
    }

    let pingGuResult = this.data.pingGuResult

    pingGuResult = this.setCompareState(pingGuResult,compareProject)

    this.setData({
      compareProject:compareProject,
      pingGuResult:pingGuResult
    })
  },

  clickCompareProject:function (e) {
    let compareProject = this.data.compareProject
    if(compareProject.length<2){
      toast.showNotice('请至少选择两个项目对比')
      return
    }
    wx.navigateTo({
      url: '/pages/ProjectCompare/ProjectCompare?pid='+compareProject.join(','),
    });

    report.click("107003")
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    common.Page.init(options)
    let pingGuResult = api.parser.parseAssessResult(app.globalData.pingGuResult)

    if(pingGuResult){
      this.setData({
        pingGuResult:pingGuResult
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})