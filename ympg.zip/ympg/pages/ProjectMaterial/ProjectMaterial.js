var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')

var downloadUrl = 'https://www.hinabian.com/project/download.html?id='

Page({
  data: {
    data: null,
    projectId:null,
    title:null,
    showPage: {
      state: 'loading'//loading、error、success
    },
  },
  clickDownload:function (e) {
    var self = this
    var url = downloadUrl + e.currentTarget.id

    wx.showModal({
      title: '下载',
      content: e.currentTarget.dataset.filename,
      success: function(res) {

        if (res.confirm) {
          toast.showLoading('正在下载...')
          const downloadTask = wx.downloadFile({
            url: url,
            success: function(res) {
              toast.showSuccess('下载成功',1000)
              var filePath = res.tempFilePath
              wx.openDocument({
                filePath: filePath,
                fileType:'xlsx',
                success: function (res) {
                },
                fail: function (e) {
                },
                complete: function () {

                }
              })
            },
            fail: function (e) {
              toast.showNotice('下载失败')
            },
            complete: function () {

            }
          })

        } else if (res.cancel) {
        }
      }
    })


  },
  onLoad: function(options) {
    common.Page.init(options)
    // Do some initialize when page load.
    this.data.projectId = options.projectId
    this.data.title = options.title

    var self = this

    util.request({
      url: api.URL.getMateriaListUrl.format(this.data.projectId),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.setData({
            data:res.data.data,
            showPage: {
              state: 'success'//loading、error、success
            },
          })
        } else {
          self.setData({
            showPage: {
              state: 'error'//loading、error、success
            },
          })
        }
      },
      fail: function () {
        // fail
        self.setData({
          showPage: {
            state: 'error'//loading、error、success
          },
        })
      }
    })
  },
  onReady: function() {
    // Do something when page ready.
  },
  onShow: function() {
    // Do something when page show.
  },
  onHide: function() {
    // Do something when page hide.
  },
  onUnload: function() {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})