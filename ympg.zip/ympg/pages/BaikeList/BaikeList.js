var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')

var nation_id = ''
var baiKeArr = []
var baiKeTab = []
var currentTab = 0
var type = ''
var scrolling = false

Page({
  data: {
    title: "百科",
    type: null,
    nation_id: null,
    showPage: {
      state: 'loading'//loading、error、success
    },
    winHeight: "",//窗口高度
    currentTab: 0, //预设当前项的值
    scrollLeft: 0, //tab标题的滚动条位置
    baiKeArr: [],
    baiKeTab: [],
    currentTab: 0,
    itemLoadState: [],
  },

  onLoad: function (options) {
    common.Page.init(options)

    var self = this
    var title = "百科 - " + options.title
    var contry = options.country
    nation_id = contry
    let type = ''
    wx.setNavigationBarTitle({
      title: title
    })

    //  高度自适应
    wx.getSystemInfo({
      success: function (res) {
        var clientHeight = res.windowHeight,
          clientWidth = res.windowWidth,
          rpxR = 750 / clientWidth;
        var calc = clientHeight * rpxR - 90;
        self.setData({
          winHeight: calc
        });
      }
    });

    //拉取百科分类tab
    util.request({
      url: api.URL.wikiTab.format(contry),
      success: function (res) {
        // success
        if (res.data.state == 0) {
          let baikeTab = res.data.data.data
          type = res.data.data.data['0']['f_id']
          let baiKeArr = []
          baikeTab.map(function (item, index) {
            baiKeArr[index] = [];
            self.data.itemLoadState[index] = {
              state: 'loading'//loading、error、success
            }
          })

          self.setData({
            title: title,
            baikeTab: baikeTab,
            baiKeArr: baiKeArr,
            itemLoadState: self.data.itemLoadState,
            showPage: {
              state: 'success'//loading、error、success
            },
          })
          self.getBaiKeInfo(contry, type, self.data.currentTab)

        } else {
          self.setData({
            showPage: {
              state: 'error'//loading、error、success
            },
          })
        }

      },
      fail: function () {
        // fail
        self.setData({
          showPage: {
            state: 'error'//loading、error、success
          },
        })
      }
    })
  },

  getBaiKeInfo: function (contry, type, index) {
    var self = this
    util.request({
      url: api.URL.wikiList.format(contry, type),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.data.baiKeArr[index] = res.data.data
          self.data.itemLoadState[index] = {
            state: 'success'//loading、error、success
          }
          self.setData({
            baikeArr: self.data.baiKeArr,
            itemLoadState: self.data.itemLoadState
          })
        } else {
          self.data.itemLoadState[index] = {
            state: 'error'//loading、error、success
          }
          self.setData({
            itemLoadState: self.data.itemLoadState
          })
        }
      },
      fail: function () {
        // fail
        self.setData({
          showPage: {
            state: 'error'//loading、error、success
          },
        })
      }
    })
  },

  jumpToDetail: function (e) {
    wx.navigateTo({
      url: '../BaikeDetail/BaikeDetail?wordId=' + e.currentTarget.dataset.id + '&title=' + e.currentTarget.dataset.title,
    });

    report.click("109002", { baike_id: e.target.dataset.id })
  },

  // 滚动切换标签样式
  switchTab: function (e) {
    let index = e.detail.current
    if (!this.data.baiKeArr[index].length) {
      let id = this.data.baikeTab[index]['f_id']
      this.getBaiKeInfo(nation_id, id, index);
    }
    this.setData({
      currentTab: e.detail.current
    });
    this.checkCor();
  },
  // 点击标题切换当前页时改变样式
  swichNav: function (e) {
    if (scrolling) {
      return false
    }
    scrolling = true
    let cur = e.target.dataset.current;
    if (this.data.currentTaB == cur) { return false; }
    else {
      if (!this.data.baiKeArr[cur].length) {
        let id = this.data.baikeTab[cur]['f_id']
        this.getBaiKeInfo(nation_id, id, cur);
      }
      this.setData({
        currentTab: cur,
      })
    }
    scrolling = false
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (this.data.currentTab > 4) {
      this.setData({
        scrollLeft: 300
      })
    } else {
      this.setData({
        scrollLeft: 0
      })
    }
  },

  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {
    // Do something when page show.
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})