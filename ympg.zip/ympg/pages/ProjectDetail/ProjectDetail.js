var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var WxParse = require('../../view/wxParse/wxParse.js');

var textContext = "<img src=\"https://cache.hinabian.com//images/release/7/1/58b2cc550325cd5e0de89ed926f5f48f.png\"/>适用于4年内成功获得过美国（B1/B2）签证，且本次申请的签证与之前相同，才可申请此免面试签证。<img src=\"https://cache.hinabian.com//images/release/7/1/58b2cc550325cd5e0de89ed926f5f48f.png\"/>适用于4年内成功获得过美国（B1/B2）签证，且本次申请的签证与之前相同，才可申请此免面试签证。";

var app = getApp()

Page({
  data: {
    projectId: null,
    data: null,
    service_fee: null,
    service_fee_old: null,
    showPage: {
      state: 'loading'//loading、error、success
    },
    bannerSize: util.scaleImageAccordingScreen({
      width: 710,
      height: 398
    }),
    tabs: [{title: "项目信息", id: "intro"},
      {title: "申请条件", id: "conditions"},
      {title: "申请流程", id: "process"},
      {title: "费用详情", id: "fee"}],
    tab0Data:null,
    tab1Data:null,
    tab2Data:null,
    tab3Data:null,
    activeIndex: 0,
    sliderOffset: 0,
    sliderLeft: 0,
    textContext1: textContext
  },

  clickTest:function (e) {
    wx.navigateTo({
      url: '/pages/TestApply/TestApply?nationProID=' + this.data.projectId,
    })

    report.click('103002')
  },

  clickTestMy:function (e) {
    wx.navigateTo({
      url: '/pages/TestApply/TestApply?nationProID=' + this.data.projectId,
    })
    report.click('103008')
  },

  clickZiXun: function (e) {
    util.call400()

    report.click('103001')
  },

  clickYuYue: function (e) {
    report.click('103003')

    if(util.isBindPhone()){
      //需要请求接口
      toast.showLoading("正在预约...")
      util.request({
        url:api.URL.saveResForApp,
        data:{
          ver:3.0,
          cid:config.cid.project,
          project_id:this.data.projectId
        },
        success: function (res) {
          // success
          toast.hideLoading()
          if (res.data.state == 0) {
            wx.showModal({
              title: '预约成功',
              content: '资深顾问会在24小时内联系您，为您提供1对1的咨询服务。',
              showCancel:false,
              confirmText:'确定',
              confirmColor:'#3FA2FF',
              success: function(res) {
              }
            })
          }
        },
        fail: function () {
          toast.showNotice('预约失败')
        },
      })
    }else{
      wx.navigateTo({
        url: '../Reservation/Reservation?projectId=' + this.data.projectId + "&img="+this.data.data.f_app_img,
      });
    }
  },

  tabClick: function (e) {
    this.setData({
      sliderOffset: e.currentTarget.offsetLeft,
      activeIndex: e.currentTarget.id
    });

    console.log('tabClick')
    console.log('this.data.tabs[0].id',this.data.tabs[0].id)
    console.log('e.currentTarget.id',e.currentTarget.id)

    if(0 == e.currentTarget.id){
      report.click('103004')
    }else if(1 == e.currentTarget.id){
      report.click('103005')
    }else if(2 == e.currentTarget.id){
      report.click('103006')
    }else if(3 == e.currentTarget.id){
      report.click('103007')
    }
  },

  clickProjectMaterial:function (e) {
    wx.navigateTo({
      url: '../ProjectMaterial/ProjectMaterial?projectId=' + this.data.projectId + '&title='+this.data.tab2Data.pName,
    });
  },

  clickJuZhu:function (e) {
    wx.showModal({
      title: '居住要求',
      content: this.data.data.residency_req.detail,
      showCancel:false,
      confirmText:'我知道了',
      confirmColor:'#3FA2FF',
      success: function(res) {
      }
    })
  },

  requestTab0: function () {
    var self = this

    util.request({
      url: api.URL.getmodinfo.format(this.data.projectId,this.data.tabs[0].id),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.data.tab0Data = res.data.data
          WxParse.wxParse('tab0Data', 'html', self.data.tab0Data, self,15);
        } else {
          self.setData({})
        }

        self.requestTab1()
      },
      fail: function () {
        // fail
        self.setData({})
      },
      complete: function () {

      }
    })
  },

  requestTab1: function () {
    var self = this

    util.request({
      url: api.URL.getmodinfo.format(this.data.projectId,this.data.tabs[1].id),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.setData({
            tab1Data:res.data.data
          })
        } else {
          self.setData({})
        }

        self.requestTab2()
      },
      fail: function () {
        // fail
        self.setData({})
      }
    })
  },
  requestTab2: function () {
    var self = this

    util.request({
      url: api.URL.getmodinfo.format(this.data.projectId,this.data.tabs[2].id),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.setData({
            tab2Data:res.data.data
          })
        } else {
          self.setData({})
        }
        self.requestTab3()
      },
      fail: function () {
        // fail
        self.setData({})
      }
    })
  },
  requestTab3: function () {
    var self = this

    util.request({
      url: api.URL.getmodinfo.format(this.data.projectId,this.data.tabs[3].id),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          self.setData({
            tab3Data:res.data.data
          })
        } else {
          self.setData({})
        }
      },
      fail: function () {
        // fail
        self.setData({})
      }
    })
  },
  onLoad: function (options) {
    common.Page.init(options)
    this.data.projectId = options.projectId

    var self = this

    util.request({
      url: api.URL.getBaseInfobyid.format(this.data.projectId),
      data: {},
      success: function (res) {
        // success
        if (res.data.state == 0) {
          var service_fee = api.parser.parseServicFee(res.data.data.service_fee)

          self.setData({
            showPage: {
              state: 'success',
            },
            data: res.data.data,
            service_fee: service_fee.fuwufei + service_fee.fuwufeiUnit,
            service_fee_old: service_fee.fuwufeiOld
          })

          self.requestTab0();
        } else {
          self.setData({
            showPage: {
              state: 'error'//loading、error、success
            },
          })
        }
      },
      fail: function () {
        // fail
        self.setData({
          showPage: {
            state: 'error'//loading、error、success
          },
        })
      },
    })
  },
  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {
    // Do something when page show.
  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})