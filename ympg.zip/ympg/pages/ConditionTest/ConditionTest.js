var common = require('../../common_js/common')
var api = require('../../common_js/api')
var config = require('../../common_js/config')
var util = require('../../common_js/util')
var toast = require('../../common_js/toast')
var report = require('../../common_js/report')
var mta = require('../../common_js/lib/mta_analysis')

Page({

  data:{

  currentCountry:{
    naID:"",
    title: "",
    subTitle: "",
    projects: []
    }

  },

  clickProItem:function(event){
    var idx = event.target.dataset.idx;
    var proId = this.data.currentCountry.projects[idx].id;
    var nation = this.data.currentCountry.title;
    wx.navigateTo({
      url: '/pages/TestApply/TestApply?nationProID=' + proId + "&nationName=" + nation,
    })
  }, 

  onLoad: function (options) {
    common.Page.init(options)

    var self = this;

    wx.request({
      url: 'https://m.hinabian.com/national/getProjectByNation?nation_id='+config.data.contryIdFG,
      data: {},
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: { // 设置请求的 header
        'content-type': 'application/x-www-form-urlencoded',
      },
      success: function (res) {
        if(res.data.state == 0){
          // success
          var resData = res.data.data[0]
          //var tmpRlt = util.conditionTestParserData(res, "大洋洲","澳大利亚");
          self.data.currentCountry.naID = resData.id;
          self.data.currentCountry.title = resData.cn_short_name;
          self.data.currentCountry.subTitle = resData.desc;
          self.data.currentCountry.projects = resData.project;

          console.log(self.data.currentCountry);
          self.setData({
            "currentCountry": self.data.currentCountry
          });
        }
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete

      }
    })


  },
  onReady: function () {
    // Do something when page ready.
  },
  onShow: function () {

  },
  onHide: function () {
    // Do something when page hide.
  },
  onUnload: function () {
    // Do something when page close.
  },

  onShareAppMessage: function () {
    // return custom share data when user share.
  },

})