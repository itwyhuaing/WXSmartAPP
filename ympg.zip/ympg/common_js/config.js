//小程序名称
var version = '3.5.2'
var projectName = 'wxxcx_ymhnb'

var datas = {

  //移民海那边
  wxxcx_ymhnb: {
    appid:'wx8fa5be9e13977e6d',
    cid:{
      assess:'wxxcx_ymhnb_assess',//评估页预约bid
      project:'wxxcx_ymhnb_project',//项目页预约bid
    },
    navigationBarTitleText: {
      home: '',
    },
    mta:{
      appId:'500551875',
      eventId:'500568298'
    },
  },
}

var Config = datas[projectName];
Config.version = version
Config.projectName = projectName

module.exports = Config