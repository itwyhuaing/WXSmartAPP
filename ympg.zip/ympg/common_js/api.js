
var URL = {}
URL.wikiDetail='https://m.hinabian.com/national/wiki_detail?id={0}'
URL.useState = 'https://m.hinabian.com/national/wiki_praise?id={0}&action={1}'
URL.wikiTab = 'https://m.hinabian.com/national/wiki_tab.html?nation_id={0}'
URL.wikiList = 'https://m.hinabian.com/national/wiki.html?nation_id={0}&type={1}'
URL.wikiListWikiHome = 'https://m.hinabian.com/national/wikiHome.html'
URL.assessNum = 'https://m.hinabian.com/assess/assessNum'
URL.miniAppLogin = 'https://m.hinabian.com/user_login/miniAppLogin'

URL.assessQa = 'https://m.hinabian.com/api_bootpage/qa?ver=3.0'
URL.assessplan = 'https://m.hinabian.com/assess/assessplan'

URL.homeBanner = 'https://m.hinabian.com/Api_Xcx/banner.html?country_id={0}&ver=3.0.0'
URL.saveResForApp = 'https://m.hinabian.com/project/saveResForApp'

URL.getBaseInfobyid = 'https://m.hinabian.com/project/getBaseInfobyid?project_id={0}'
URL.getmodinfo = 'https://m.hinabian.com/project/getmodinfo?project_id={0}&mod_id={1}'
URL.getMateriaListUrl = 'https://m.hinabian.com/project/getMateriaList?project_id={0}'
URL.saveTestForApp = 'https://m.hinabian.com/assess/saveTestForApp.html?project_id={0}'
URL.testForApp = 'https://m.hinabian.com/assess/testForApp.html?project_id={0}'
URL.projectcompare = 'https://m.hinabian.com/assess/projectcompare?pid={0}'
URL.getWXUserInfo = 'https://m.hinabian.com/user_login/getWXUserInfo'
URL.vcode = 'https://www.hinabian.com/vcode'

/* ------------------------------------------------------------------------------------ */
var parser = {}

parser.assessQa = function (questionArr) {
  if(questionArr){
    for(let i = 0 ;i<questionArr.length ; i++){
        if(i == 0 || i == 1){
          questionArr[i].type = 3
        }else if(i == 2 || i == 3 || i == 4|| i == 6){
          questionArr[i].type = 2
        }else if(i == 5){
          questionArr[i].type = 1
        }else{
          questionArr[i].type = 2
        }
    }
  }
  return questionArr
}
parser.assessAnswers = function (questionArr) {
  let answers = []
  if(questionArr){
    answers = new Array(questionArr.length)
    for (let i = 0; i < questionArr.length; i++) {
      answers[i] = []
    }
  }
  return answers
}

parser.parseAssessResult = function (pingGuResult) {
  return pingGuResult
}


parser.parseServicFee = function(service_fee) {
  var servicFee={
    fuwufei:"",
    fuwufeiUnit:"",
    fuwufeiOld:"",
  }
  servicFee.fuwufei = service_fee ? service_fee.current : ''
  servicFee.fuwufeiUnit = ''
  if (servicFee.fuwufei >= 10000) {
    servicFee.fuwufei = servicFee.fuwufei / 10000
    servicFee.fuwufeiUnit = '万'
  }

  servicFee.fuwufeiOld = service_fee ? service_fee.original : ''
  if (servicFee.fuwufeiOld != '' && servicFee.fuwufeiOld != '0') {
    if (servicFee.fuwufeiOld >= 10000) {
      servicFee.fuwufeiOld = servicFee.fuwufeiOld / 10000 + '万'
    }
  }
  return servicFee;

}



var API = {
  URL:URL,
  parser:parser,
}

module.exports = API