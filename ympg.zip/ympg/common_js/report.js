//统计js
var config = require('./config')

var mta = require('./lib/mta_analysis')

var pvAppUrl = 'https://data.hinabian.com/stat/pvApp?platform=wxxcx'
var clickAppUrl = 'https://data.hinabian.com/stat/clickApp?platform=wxxcx'

var data = {}
data.platform;// android /ios
data.scene;//打开小程序的场景值
data.path;//打开小程序的路径
data.version;
data.projectName;
data.channel = 'none';//渠道号
data.scene_channel;//场景号-渠道号
data.f_os = 'wxxcx';//上报平台
data.f_channel;//上报渠道号   参数中添加的格式：f_channel：(iOS/Android)-(小程序场景ID)-(外部渠道cid)  例如： iOS-1011-xcx.wxpyq.jl
data.content;//上报content


/**
 * 初始化项目版本号和名称
 */
function init(options,version,projectName){
  data.version =version
  data.projectName =projectName

  //获取外部渠道号
  if(options && options.query && options.query.channel){
    wx.setStorageSync('channel', options.query.channel);
  }
  let channelStorage = wx.getStorageSync('channel');
  if(channelStorage){
    data.channel = channelStorage
  }else{
    data.channel = '0000' //默认值
  }

  if (options){
    data.path = options.path
    data.scene = options.scene
  }else{
    data.path = 'null'
    data.scene = 'null'
  }
  
  data.scene_channel= data.scene + '-' + data.channel

  var res = wx.getSystemInfoSync()
  data.platform = res.platform

  data.content = {
    f_os: data.f_os,
    f_clien: data.projectName,
    f_channel: data.platform + '-' + data.scene_channel,
    f_app_version: data.version
  }
}

var extend=function(o,n){
  for (var p in n){
    if(n.hasOwnProperty(p) && (!o.hasOwnProperty(p) ))
      o[p]=n[p];
  }
};


function pv(pageName){
  var dataJson = {
    count:'1',
    uploadingTime: new Date().getTime(),
    pv:[{id:pageName,content: data.content}]
  }

  wx.request({
    url: pvAppUrl,
    method: 'POST',
    header: {// 设置请求的 header
      'cookie': wx.getStorageSync('appSessionKey'),
    },
    data: dataJson
  })
}

function click(clickName,param) {
  let content = {};
  extend(content,data.content);
  if(param){
    extend(content,param);
  }

  var dataJson = {
    count: '1',
    uploadingTime: new Date().getTime(),
    click: 
    [
      { 
        id: clickName,
        content: content
      }
    ]
  }

  wx.request({
    url: clickAppUrl,
    method: 'POST',
    header: {// 设置请求的 header
      'cookie': wx.getStorageSync('appSessionKey'),
    },
    data: dataJson
  })

  //腾讯统计
  mta.Event.stat("204005",param ? param : {})
}

function getChannel() {
  let channel = '0000'
  try {
    channel = wx.getStorageSync('channel')
  } catch (e) {
  }
  return channel
}

/**
 *
 * @param bid
 * @param cid 获客cid
 * @returns {string}
 */
var getCRMCid = function (bid,cid) {
  if (!bid || bid == '') {
    bid = '0000'
  }
  if (!cid || cid == '') {
    cid = '0000'
  }
  return this.getChannel() + '--' + bid + '--' + config.projectName + '--' + cid
}


module.exports = {
  init,pv,click,data,getChannel,getCRMCid
}