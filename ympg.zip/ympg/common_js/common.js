var report = require('./report')
var config = require('./config')
var mta = require('./lib/mta_analysis')

function getPagePath() {
  try {
    var a = getCurrentPages(), b = "/";
    0 < a.length && (b = a.pop().__route__);
    return b
  } catch (c) {
    console.log("get current page path error:" + c)
  }
}


var App = {}

/**
 * app.onLaunch方法中调用
 * @param options
 */
App.init = function (options) {
  report.init(options,config.version,config.projectName)

  //腾讯统计平台
  try {
    mta.App.init({
      "appID": config.mta.appId,
      "eventID": config.mta.eventId,
      "lauchOpts": options,
      "statShareApp": true,
    });
  } catch (e) {

  }
}


var Page = {}
/**
 * page页面onLoad会回调
 * @param options
 */
Page.callOnLoad = function (options) {
  //腾讯统计页面初始化
  mta.Page.init()
}

/**
 * page页面onShow会回调
 */
Page.callOnShow = function () {
  report.pv(getPagePath())
}


/**
 * 在page的onload中初始化
 */
Page.init = function (options) {
  Page.callOnLoad(options)

  var page = getCurrentPages()[getCurrentPages().length - 1];
  page.onShow && ! function () {
    var onShow = page.onShow
    page.onShow = function () {
      Page.callOnShow()
      onShow.call(this,arguments)
    }
  }()
}

var Common = {
  App : App,
  Page:Page
}

module.exports = Common