var config = require('./config')
var api = require('./api')

String.prototype.format=function()
{
  if(arguments.length==0) return this;
  for(var s=this, i=0; i<arguments.length; i++)
    s=s.replace(new RegExp("\\{"+i+"\\}","g"), arguments[i]);
  return s;
};

function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}


// post 数据时格式化参数 数据
function json2Form(json){
  var str = [];
  for(var p in json){
    str.push(encodeURIComponent(p)+"="+encodeURIComponent(json[p]));
  }
  return str.join("&");
}

/**
 * 合并对象
 * 1.循环对象n中的每一个对应属性。
   2.确认对象n中存在该属性
   3.确认对象o中不存在该属性
 * @param o   将n的属性设置到o中
 * @param n  被循环的对象
 */
var extend=function(o,n){
  for (var p in n){
    if(n.hasOwnProperty(p) && (!o.hasOwnProperty(p) ))
      o[p]=n[p];
  }
};


// 图片依据屏幕尺寸等比例缩放
function scaleImageAccordingScreen(imageSize){

  var imgSize = {
    imgWidth: imageSize.width,
    imgHeight: imageSize.height,
    ratio:1
  };
  wx.getSystemInfo({
    success: function(res) {
      var screenWidth = res.windowWidth;
      var screenHeight = res.windowHeight;

      imgSize.ratio = screenWidth / imgSize.imgWidth;
      imgSize.imgHeight = imgSize.imgHeight * imgSize.ratio;
      imgSize.imgWidth = screenWidth;

    }
  })
  return imgSize;
}

// 获取可使用窗口尺寸px，不在onload中调用会不准确
function getScreen(){
  var size = {};
  wx.getSystemInfo({
    success: function(res) {
      size = {
        width:res.windowWidth,
        height:res.windowHeight};
    }
  })
  return size;
}


/**
 * 判断是否null
 * @param data
 */
function isEmpty(data) {
  return (data == "" || data == undefined || data == null);
}

/**
 * 验证国内手机号
 */
function chineseMobile(mobile) {
  return !isEmpty(mobile) && /^(13[0-9]|14[0-9]|15[0-9]|18[0-9]|17[0-9])\d{8}$/.test(mobile);
}

function checkVCode(code){
  return !isEmpty(code) && /^\d{6}$/.test(code);
}

function getCookie() {
  return wx.getStorageSync('appSessionKey')
}

function saveCookie(HNBSESSIONID){
  wx.setStorageSync('appSessionKey', "HNBSESSIONID=" + HNBSESSIONID);
}

function setWXPhoneNum(phone) {
  wx.setStorageSync('WXPhoneNum', phone);
}

function getWXPhoneNum() {
  return  wx.getStorageSync('WXPhoneNum')
}



function isBindPhone() {
  return 1 == wx.getStorageSync('isBindPhone')
}

function setBindPhone(isBindPhone) {
  wx.setStorageSync('isBindPhone', isBindPhone);
}


/**
 * 微信登录
 * @param callback
 *  callback = {
 *    success:function(){},
 *    fail:function(){},
 *  }
 */
function wxLogin(callback) {
  wx.login({
    success: function(res) {
      if (res.code) {
        request({
          url: api.URL.miniAppLogin,
          data:{
            appid:config.appid,
            code:res.code,
          },
          method: 'GET',
          success: function(res){
            if(res.data.state == 0){
              saveCookie(res.data.data.sid)
              setBindPhone(res.data.data.hasPhone)

              if(callback){
                callback.success()
              }
            }else{
              if(callback){
                callback.fail()
              }
            }
          },
          fail: function(res) {
            if(callback){
              callback.fail()
            }
          },
        })
      } else {
        if(callback){
          callback.fail()
        }
      }
    }
  })
}

/**
 * 请求授权获取用户信息
 * @param callback
 *  callback = {
 *    success:function(userInfo){},
 *    fail:function(){},
 *  }
 */
function wxGetUserInfo(callback) {
  wx.getUserInfo({
    success: function(res) {
      if(callback){
        callback.success(res.userInfo)
      }
    },
    fail: function () {
      // 在这里做一下兼容，有些同行业的用户会点击拒绝玩一玩看你们的小程序是否存在bug，
      // 所以在这里还是加上下面这两行代码吧，打开微信小程序的设置，允许小程序重新授权的页面
      wx.openSetting({
        success: function(res){
          // 下面的代码格式按照我的写，不要看工具打印的什么，在这里提醒大家一句，有时候不能相信开发者工具，因为
          // android和ios还有工具底层的js库是不同的，有些时候坑的你是一点脾气也没有，所以大家注意一下，
          // 不相信的慢慢的去自己跳坑吧
          if (res.authSetting["scope.userInfo"]) {
            // 进入这里说明用户重新授权了，重新执行获取用户信息的方法
            wx.getUserInfo({
              success: function (res) {
                if(callback){
                  callback.success(res.userInfo)
                }
              }
            })
          }else{
            if(callback){
              callback.fail(res.userInfo)
            }
          }
        }
      })
    }
  })
}

function querySubstrFromString(json) {
  var rlt = true;
  for (var p in json) {
    if (json[p].length <= 0){
      rlt = false;
      break;
    }
  }
  return rlt;
}



function call400() {
  wx.makePhoneCall({
    phoneNumber: '4009933922',
    success: function () {
      console.log("拨打电话成功！")
    },
    fail: function () {
      console.log("拨打电话失败！")
    }
  })
}

function call400HaiFang() {
  wx.makePhoneCall({
    phoneNumber: '4009933922,2',
    success: function () {
      console.log("拨打电话成功！")
    },
    fail: function () {
      console.log("拨打电话失败！")
    }
  })
}

//保留两位小数
//功能：将浮点数四舍五入，取小数点后2位
function toDecimal(x) {
  var f = parseFloat(x);
  if (isNaN(f)) {
    return;
  }
  f = Math.round(x*100)/100;
  return f;
}

/**
 * 封装wx.request
 * util.request({
      url: '',
      success: function (res) {}
      fail:function(){}
      complete:function(){}
    })
 *
 * @param obj
 */
function request(obj) {
  if(!obj){
    return
  }

  if(!obj.data){
    obj.data = {}
  }
  obj.data.projectName = config.projectName
  obj.data.version = config.version

  if(!obj.method){
    obj.method = 'POST'
  }

  if(!obj.header){
    obj.header = {}
  }

  if(!obj.header['content-type']){
    obj.header['content-type'] = 'application/x-www-form-urlencoded'
  }
  obj.header.cookie=getCookie()

  wx.request(obj)
}

function randomInt(n, m){
  var random = Math.floor(Math.random()*(m-n+1)+n);
  return random;
}

module.exports = {
  isEmpty,
  chineseMobile,
  checkVCode,
  formatTime,
  scaleImageAccordingScreen,
  json2Form,
  getScreen,
  extend,
  wxLogin,
  call400,
  getCookie,
  isBindPhone,
  setBindPhone,
  toDecimal,
  setWXPhoneNum,
  getWXPhoneNum,
  request,
  randomInt,
  querySubstrFromString,
  call400HaiFang,
}
