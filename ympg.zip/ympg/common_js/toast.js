var defaultDuration = 3000
var imgNotice = "/images/ic_toast_notice.png"

function showSuccess(title,duration){
  let d = defaultDuration;
  if(duration){
    d = duration;
  }
  wx.showToast({
    icon:"success",
    title: title,
    duration: d
  })
}

function showNotice(title, duration) {
    let d = defaultDuration;
    if (duration) {
      d = duration;
    }
    wx.showToast({
      title: title,
      image: imgNotice,
      duration: d
    })
}

function showToast(title, duration) {
  let d = defaultDuration;
  if (duration) {
    d = duration;
  }
  wx.showToast({
    title: title,
    duration: d
  })
}

function hideToast(){
  wx.hideToast();
}

function showLoading(title){
  if(title){
    // wx.showLoading({
    //   title: title
    // })
    wx.showToast({
      title: title,
      icon: 'loading',
      duration: 200000,
      mask:true,
    })
  }else{
    // wx.showLoading({
    //   title: "正在加载..."
    // })
    wx.showToast({
      title: "正在加载...",
      icon: 'loading',
      duration: 200000,
      mask:true,
    })
  }
}

function hideLoading(){
  wx.hideToast()
}

module.exports = {
  showNotice: showNotice,
  showSuccess: showSuccess,
  hideToast: hideToast,
  hideLoading: hideLoading,
  showLoading: showLoading,
  showToast:showToast
}