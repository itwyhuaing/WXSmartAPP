//app.js
var common = require('./common_js/common')

App({
  // 全局数据
  globalData:{
    pingGuResult: null,
    imassessedCount:39858//评估人数
  },

  onLaunch: function (options) {
    common.App.init(options)

    this.globalData.pingGuResult = wx.getStorageSync('KeyPingGuResult')
  },

})